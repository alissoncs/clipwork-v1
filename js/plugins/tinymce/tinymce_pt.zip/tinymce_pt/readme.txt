Ola pessoal.

Vejam bem: 

Editor web para o seu CMS com administração de fotos e em Português. Barbada de implementar. 


1º passo: 
 
 - Faça download do editor no link do 4shared.com.
 - Descompacte a pasta tinymce_PT, copie esta e coloe dentro da sua pasta raiz do local/remoto server. Caso esteja a testar em um server local... então (www, httpdocs, etc) que será respondida pelo http://localhost( servidor local PHP).
 - Abra o navegador com excessão do IEca 6 e digite... http://localhost/tinymce_pt
 - Deve aparecer Index of /tinymce_1.
 - Clique na pasta "examples"
 - O exemplo que ajustei se chama "Exemplo customizado(indicado)".
 - Veja que a barra está menor com apenas algum dos icones mais utilizados para o CMS de um site.
 - Bom agora siga as telas do tutorial para usar. Mas veja como é simples este editor.
 
2º passo:
 
 - Quero usar no meu gerenciador de site como faço?
 - Na pasta "examples" tem um arquivo chamado "full.html".
 - Abra o arquivo com um editor (se estiver no linux pode ser o gedit ou se estiver instalado o eclipse(com aptana plugin), ou netbeans etc. Caso esteja no Windows notepad ou dreamweaver etc). Enfim um local onde você consiga ver o código html do arquivo.
 - Copie o que esta entre as tags <head> ... </head> com excessão do <title>Exemplo Customizado</title> e cole entre as tags <head> ... </head> do seu gerenciador de conteudo de seu site.
 - Beleza ... onde estiver  a tag <textarea> nesta página ele vai adicionar o tinymce.

Espero que tenha curtido

Grande abraço à todos.
